import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slider-login-component',
  templateUrl: './slider-login-component.component.html',
  styleUrls: ['./slider-login-component.component.css']
})
export class SliderLoginComponentComponent implements OnInit {
  welcomenote:string = "Welcome to KLM";
  slideindex:number = 1;                  
  resourceList = [
    "../../assets/images/image1.JPG",
    "../../assets/images/image2.jpg",
    "../../assets/images/image3.jpg",
    "../../assets/images/image4.jpg"
  ];
  constructor() { 
  }
  ngOnInit() {
    this.displaySlides(this.slideindex); 
  }
  nextSlide(n) {
     this.displaySlides(this.slideindex += n);
  }
  displaySlides(n) {
        let i;            
        let slides:any = document.getElementsByClassName("showSlide");
        if (n > slides.length) { 
              this.slideindex = 1; 
        }
        if (n < 1) { 
              this.slideindex = slides.length; 
        }
        for (let i = 0; i < slides.length; i++) {
                    slides[i].style.display = "none";
        }            
        slides[this.slideindex - 1].style.display = "block";
  }
   currentSlide(n) {
      this.displaySlides(this.slideindex = n);
  }
}
