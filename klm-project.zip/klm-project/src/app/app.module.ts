import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SliderLoginComponentComponent } from './slider-login-component/slider-login-component.component';
import { HomePageComponentComponent } from './home-page-component/home-page-component.component';

@NgModule({
  declarations: [
    AppComponent,
    SliderLoginComponentComponent,
    HomePageComponentComponent
  ],
  imports: [
    RouterModule,
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
