import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {SliderLoginComponentComponent} from '../app/slider-login-component/slider-login-component.component';
import {HomePageComponentComponent} from '../app/home-page-component/home-page-component.component';

const routes: Routes = [
  {path: '' , component: SliderLoginComponentComponent},
  {path: 'Home' , component: HomePageComponentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
