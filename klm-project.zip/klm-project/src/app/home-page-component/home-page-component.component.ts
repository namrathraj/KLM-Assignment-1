import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-page-component',
  templateUrl: './home-page-component.component.html',
  styleUrls: ['./home-page-component.component.css']
})
export class HomePageComponentComponent implements OnInit {
  
  title = "CEO & Founder, KLM";
  empName = "Alexa";
  headOffice = "Amsterdam";
  contactTitle = "Contact"; 
  constructor() { }

  ngOnInit() {
  }


}
